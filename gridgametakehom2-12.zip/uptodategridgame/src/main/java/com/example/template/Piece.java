package com.example.template;

public class Piece {

        private int xcord = 0;
        private int  ycord = 0;
        private String type = "";
        private int team=9999;

        public Piece(int xstart, int ystart, String type,int team) {
            xcord = xstart;
            ycord = ystart;
            this.type = type;
            this.team=team;

        }
        public int getteam(){
            return team;
        }
        public String gettype(){
            return type;
        }

        public void changecords(int x, int y) {
            xcord = x;
            ycord = y;
        }

        public int getxcord() {
            return xcord;
        }

        public int getycord() {
            return ycord;
        }


    public void move(Tile[][] tiles) {

        if (type.equals("random")) {
            int rnum = (int)(Math.random() * 4);

            if (rnum == 0) {
                int x = xcord + 1;
                int y = ycord;

                if (!tiles[x][y].getisthereawall() && !tiles[x][y].getisthereapiece() && !tiles[x][y].getcolor().equals("Black")) {

                    xcord = x;
                }
            }

            if (rnum == 1) {
                int x = xcord - 1;
                int y = ycord;

                if (!tiles[x][y].getisthereawall() && !tiles[x][y].getisthereapiece() && !tiles[x][y].getcolor().equals("Black")) {

                    xcord = x;
                }
            }

            if (rnum == 2) {
                int x = xcord;
                int y = ycord + 1;

                if (!tiles[x][y].getisthereawall() && !tiles[x][y].getisthereapiece() && !tiles[x][y].getcolor().equals("Black")) {

                    ycord = y;
                }
            }

            if (rnum == 3) {
                int x = xcord;
                int y = ycord - 1;

                if (!tiles[x][y].getisthereawall() && !tiles[x][y].getisthereapiece() && !tiles[x][y].getcolor().equals("Black")) {

                    ycord = y;
                }
            }
        }

        else if (type.equals("horizontal line left")) {
            int x = xcord;
            int y = ycord + 1;

            if (!tiles[x][y].getisthereawall() && !tiles[x][y].getisthereapiece() && !tiles[x][y].getcolor().equals("Black")) {
                ycord = y;
            }
        }

        else if (type.equals("horizontal line right")) {
            int x = xcord;
            int y = ycord - 1;

            if (!tiles[x][y].getisthereawall() && !tiles[x][y].getisthereapiece() && !tiles[x][y].getcolor().equals("Black")) {

                ycord = y;
            }
        }

        else if (type.equals("vertical line up")) {
            int x = xcord + 1;
            int y = ycord;

            if (!tiles[x][y].getisthereawall() && !tiles[x][y].getisthereapiece() && !tiles[x][y].getcolor().equals("Black")) {

                xcord = x;
            }
        }

        else if (type.equals("vertical line down")) {
            int x = xcord - 1;
            int y = ycord;

            if (!tiles[x][y].getisthereawall() && !tiles[x][y].getisthereapiece() && !tiles[x][y].getcolor().equals("Black")) {

                xcord = x;
            }
        }else if (type.equals("wall")){
            int x = xcord;
            int y = ycord;
            team=3;


            }
        else if (type.equals("rat")){
            team=3;
            int rnum2 = (int)(Math.random() * 4);

            if (rnum2 == 0) {
                int x = xcord + 1;
                int y = ycord;

                if (!tiles[x][y].getisthereawall()  && !tiles[x][y].getcolor().equals("Black")) {

                    xcord = x;
                }
            }

            if (rnum2 == 1) {
                int x = xcord - 1;
                int y = ycord;

                if (!tiles[x][y].getisthereawall() && !tiles[x][y].getcolor().equals("Black")) {

                    xcord = x;
                }
            }

            if (rnum2 == 2) {
                int x = xcord;
                int y = ycord + 1;

                if (!tiles[x][y].getisthereawall() && !tiles[x][y].getcolor().equals("Black")) {

                    ycord = y;
                }
            }

            if (rnum2 == 3) {
                int x = xcord;
                int y = ycord - 1;

                if (!tiles[x][y].getisthereawall() &&!tiles[x][y].getcolor().equals("Black")) {

                    ycord = y;
                }
            }
        }
        }
    }






