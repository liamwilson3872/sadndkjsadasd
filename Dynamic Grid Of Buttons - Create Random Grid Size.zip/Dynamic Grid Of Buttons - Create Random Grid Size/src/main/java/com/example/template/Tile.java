package com.example.template;

public class Tile {

    private String color;


    public Tile(String color1){
        color=color1;

    }

    public String getcolor(){
        return color;
    }

    public void changecolor(String color1){
        color=color1;
    }

}
