package com.example.template;

public class Robot {

    public Robot(){

    }

}
