package com.example.template;

public class Gameplay {

    private Tile[][] tiles;
    private String[] randomcolor={"Red","Blue","Green","Yellow"};
    private int size=0;

    public Gameplay(int size) {
        this.size=size;
    }

    public void maketiles(){
        tiles=new  Tile[size][size];
        int rnum=(int)(Math.random()*randomcolor.length);
        for (int i=0;i<size;i++){
            for (int j=0;j<size;j++){
                if (i==0){
                    tiles[i][j]=new Tile("Black");

                }else if (j==0){
                    tiles[i][j]=new Tile("Black");

                }else if (j==size-1){
                    tiles[i][j]=new Tile("Black");

                }else if (i==size-1){
                    tiles[i][j]=new Tile("Black");

                }
                else {
                    tiles[i][j] = new Tile(randomcolor[rnum]);
                }
            }
        }

    }

    public Tile[][] getcolors(){
        Tile[][] temp = new Tile[size][size];
        for (int i=0;i<size;i++){
            for (int j=0;j<size;j++){
                temp[i][j]=new Tile(tiles[i][j].getcolor());
            }
        }
        return temp;
    }

//    public void update()

    public void printboard(){
        for (int i=0;i<tiles.length;i++){
            for (int j=0;j<tiles[i].length;j++){
                System.out.print(tiles[i][j].getcolor());
            }

        }
    }
    public Tile[][] gettiles(){
        return tiles;
    }

}


