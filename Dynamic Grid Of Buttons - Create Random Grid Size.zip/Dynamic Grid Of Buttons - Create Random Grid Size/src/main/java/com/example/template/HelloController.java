package com.example.template;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

import java.awt.*;

public class HelloController {

    public Button btnClick;
    public Label lblDisplay;
    public TextField txtInput;
    public GridPane gpane;
    public Button colorbtn;
    public TextField colortxt;
    public Button upt;
    private Button[][] btn;
    private Gameplay game;


    public void initialize(){
        int x = 20;
        int y = 20;
        btn = new Button[x][y];

        gpane.getChildren().clear();
        gpane.setGridLinesVisible(true);
        for (int i = 0; i < btn.length; i++) {
            for (int j = 0; j < btn[0].length; j++) {
                btn[i][j] = new Button("   ");
                gpane.add(btn[i][j], j, i);
            }
        }


        // same structure, now for MouseEvent
        EventHandler<MouseEvent> z = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                System.out.println(event.getSource());
//                gpane.setGridLinesVisible(true);
                Button clicked = (Button) event.getSource();
                int row = GridPane.getRowIndex(clicked);
                int col = GridPane.getColumnIndex(clicked);
                System.out.println("(" + row + "," + col + ")");

                if (event.getButton() == MouseButton.PRIMARY) {
                    System.out.println("LEFT click");
                } else if (event.getButton() == MouseButton.SECONDARY) {
                    System.out.println("RIGHT click");

                }

                btn[row][col].setText("clicked");
                blank();
            }
        };

        for (int i = 0; i < btn.length; i++) {
            for (int j = 0; j < btn[0].length; j++) {
                btn[i][j].setOnMouseClicked(z);   // same pattern as your setOnAction
            }
        }
        //resets the gridlines
        gpane.setGridLinesVisible(false);
        gpane.setGridLinesVisible(true);
    }



    public void handleClick(ActionEvent actionEvent) {
        String str=colortxt.getText();
        int x= Integer.parseInt(str.substring(0,1));
        int y=Integer.parseInt(str.substring(2,str.length()-1));
        btn[x][y].setStyle("-fx-background-color: Yellow");
    }
    public void blank(){

    }
    public void update(){
        Tile[][] board1=game.getcolors();
        for (int i=0;i<board1.length;i++){
            for (int j=0;j<board1[i].length;j++){
                game.gettiles()[i][j].changecolor("Orange");
                btn[i][j].setStyle("-fx-background-color: "+game.gettiles()[i][j].getcolor());
            }
        }
    }

    public void colorbtn(ActionEvent actionEvent) {
        game=new Gameplay(20);
        game.maketiles();
            for (int i=0;i<game.gettiles().length;i++){
                for (int j=0;j<game.gettiles()[i].length;j++){
                    System.out.print(game.gettiles()[i][j].getcolor());
                    btn[i][j].setStyle("-fx-background-color:"+game.gettiles()[i][j].getcolor());
                }

            }
        }

}