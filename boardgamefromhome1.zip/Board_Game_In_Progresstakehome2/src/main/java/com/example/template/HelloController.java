package com.example.template;

import javafx.animation.AnimationTimer;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;


public class HelloController {

    public Button btnClick;
    public Label lblDisplay;
    public TextField txtInput;
    public GridPane gpane;
    public Button colorbtn;
    public TextField colortxt;
    public Button upt;
    public Button rbtbtn;
    public Button movebtn;
    public Button evilmakebtn;
    public Button moveevilbtn;
    public Button anitmr;
    public TextField txt1;
    public TextField txt2;
    public Button confirmbtn;
    private Button[][] btn;
    private Gameplay game;
    private boolean isroboton=false;
    private boolean isevilroboton=false;
    private long timeelapsed;
    private int delay=0;


    public void initialize(){

    }



    public void handleClick(ActionEvent actionEvent) {

    }
    public void blank(){

    }
    public void update(){
        Tile[][] board1=game.getcolors();
        for (int i=0;i<board1.length;i++){
            for (int j=0;j<board1[i].length;j++){
                btn[i][j].setStyle("-fx-background-color: "+game.gettiles()[i][j].getcolor());
            }
        }

        for (int i=0;i<game.getpieces().size();i++){
            if (game.getpiece(i).getteam()==0) {
                btn[game.getpiece(i).getxcord()][game.getpiece(i).getycord()].setStyle("-fx-background-color: #01c399");
            }else if (game.getpiece(i).getteam()==1){
                btn[game.getpiece(i).getxcord()][game.getpiece(i).getycord()].setStyle("-fx-background-color: #ff3b50");
            }

        }

    }

    public void starttimer(ActionEvent actionEvent) {
        timeelapsed = System.nanoTime(); //only needed if want a specific amount of time to pass with timer
        handleStartAnimation();//use if want a timer to go as fast as possible
//        handleStartAnimation2();//use if want to control a timers speed
    }
    public void handleStartAnimation() {
        new AnimationTimer(){
            @Override
            public void handle(long now) {
                if(game.gettiles().length>0){
                    if (game.getpieces().size()!=0){
                        if (delay==10){
                            game.move();
                            delay=0;
                            update();
                        }else{
                            delay+=1;
                        }


                    }


                }



                update();
            }

        }.start();
    }


    public void makerobot(ActionEvent actionEvent) {
        int x= Integer.parseInt(txt1.getText());
        int y= Integer.parseInt(txt2.getText());

        game.makepiece(x,y,"horizontal line");
        isroboton=true;
        update();

    }






    public void handlestartanimationtimer(ActionEvent actionEvent) {

    }

    public void confirm(ActionEvent actionEvent) {
        int x = Integer.parseInt(txt1.getText());
        int y = Integer.parseInt(txt2.getText());
        btn = new Button[x][y];

        gpane.getChildren().clear();
        gpane.setGridLinesVisible(true);
        for (int i = 0; i < btn.length; i++) {
            for (int j = 0; j < btn[0].length; j++) {
                btn[i][j] = new Button("   ");
                gpane.add(btn[i][j], j, i);
            }
        }


        // same structure, now for MouseEvent
        EventHandler<MouseEvent> z = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                System.out.println(event.getSource());
//                gpane.setGridLinesVisible(true);
                Button clicked = (Button) event.getSource();
                int row = GridPane.getRowIndex(clicked);
                int col = GridPane.getColumnIndex(clicked);

                if (event.getButton() == MouseButton.PRIMARY) {
                    System.out.println("LEFT click");
                    if (!(game.gettiles()[row][col].getcolor().equals("Black"))){
                        System.out.println("Tile");


                    }else{
                        System.out.println("Wall");
                        if (row==0){
                            System.out.println("Open "+row+col);
                            game.makepiece(row+1,col,"vertical line up");
                            isroboton=true;
                            update();
                        }else if (row==game.getxsize()-1){
                            System.out.println("Open "+row+col);
                            game.makepiece(row-1,col,"vertical line down");
                            isroboton=true;
                            update();

                        }else if (col==0){
                            System.out.println("Open "+row+col);
                            game.makepiece(row,col+1,"horizontal line left");
                            isroboton=true;
                            update();

                        }else if (col==game.getysize()-1){
                            System.out.println("Open "+row+","+col);
                            game.makepiece(row,col-1,"horizontal line right");
                            isroboton=true;
                            update();
                        }
                    }

                } else if (event.getButton() == MouseButton.SECONDARY) {
                    System.out.println("RIGHT click");

                }

                blank();
            }


        };

        for (int i = 0; i < btn.length; i++) {
            for (int j = 0; j < btn[0].length; j++) {
                btn[i][j].setOnMouseClicked(z);   // same pattern as your setOnAction
            }
        }
        //resets the gridlines
        gpane.setGridLinesVisible(false);
        gpane.setGridLinesVisible(true);
        game=new Gameplay(x,y);
        game.maketiles();
        for (int i=0;i<game.gettiles().length;i++){
            for (int j=0;j<game.gettiles()[i].length;j++){
                btn[i][j].setStyle("-fx-background-color:"+game.gettiles()[i][j].getcolor());
            }

        }
        game.makepattern();
        update();


    }
}