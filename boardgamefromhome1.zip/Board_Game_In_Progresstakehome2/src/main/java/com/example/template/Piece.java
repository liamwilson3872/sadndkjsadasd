package com.example.template;

public class Piece {

        private int xcord = 0;
        private int  ycord = 0;
        private String type = "";
        private int team=9999;

        public Piece(int xstart, int ystart, String type,int team) {
            xcord = xstart;
            ycord = ystart;
            this.type = type;
            this.team=team;

        }
        public int getteam(){
            return team;
        }

        public void changecords(int x, int y) {
            xcord = x;
            ycord = y;
        }

        public int getxcord() {
            return xcord;
        }

        public int getycord() {
            return ycord;
        }


        public void move(Tile[][] tiles) {
            if (type.equals("random")) {
                int rnum = (int) (Math.random() * 4);
                if (rnum==0) {
                    if (tiles[xcord + 1][ycord].getisthereawall() == false && !(tiles[xcord+1][ycord].getcolor().equals("black"))) {
                        xcord += 1;
                    }
                }
                if (rnum ==1) {
                    if (tiles[xcord - 1][ycord].getisthereawall() == false && !(tiles[xcord-1][ycord].getcolor().equals("black"))) {

                        xcord -= 1;
                    }
                }
                if (rnum==2) {
                    if (tiles[xcord][ycord + 1].getisthereawall() == false && !(tiles[xcord][ycord+1].getcolor().equals("black"))) {

                        ycord += 1;
                    }
                }
                if (rnum==3) {
                    if (tiles[xcord][ycord - 1].getisthereawall() == false&& !(tiles[xcord][ycord-1].getcolor().equals("black"))) {

                        ycord -= 1;
                    }
                }
            } else if (type.equals("horizontal line left")){
                    if (!(tiles[xcord][ycord + 1].getisthereawall() == true && !(tiles[xcord][ycord+1].getcolor().equals("black")))) {
                        ycord += 1;


                }

            }else if (type.equals("horizontal line right")){
                    if (!(tiles[xcord][ycord -1].getisthereawall() == true&& !(tiles[xcord][ycord-1].getcolor().equals("black")))) {
                        ycord -= 1;

                    }

            }


            else if (type.equals("vertical line up")){
                    if (!(tiles[xcord+1][ycord].getisthereawall() == true&& !(tiles[xcord+1][ycord].getcolor().equals("black")))) {
                        xcord += 1;


                }
            }else if (type.equals("vertical line down")){
                    if (!(tiles[xcord-1][ycord].getisthereawall() == true )) {
                        xcord -= 1;

                    }

            }


            else{
                System.out.println("Swahelle");
            }
        }
    }





