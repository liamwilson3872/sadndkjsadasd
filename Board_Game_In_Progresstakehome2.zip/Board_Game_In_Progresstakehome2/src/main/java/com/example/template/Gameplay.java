package com.example.template;

import java.util.ArrayList;

public class Gameplay {

    private Tile[][] tiles;
    private String[] randomcolor={"Green"};
    private int size=0;
    private int size2=0;
    private Piece robot;
    private Piece evilrobot;
    private long timeElapsed;

    private ArrayList<Piece> pieces=new ArrayList<>();
    private int turn=0;

    public Gameplay(int size,int size2) {
        this.size=size;
        this.size2=size2;
    }

    public void maketiles(){
        tiles=new  Tile[size][size2];
        int rnum=(int)(Math.random()*randomcolor.length);
        for (int i=0;i<size;i++){
            for (int j=0;j<size2;j++){
                if (i==0 || j==0 || i==size-1 || j==size2-1){
                    tiles[i][j]=new Tile("Black");

                }else {
                    tiles[i][j] = new Tile(randomcolor[rnum]);
                }
            }
        }

    }

    public Tile[][] getcolors(){
        Tile[][] temp = new Tile[size][size2];
        for (int i=0;i<size;i++){
            for (int j=0;j<size2;j++){
                temp[i][j]=new Tile(tiles[i][j].getcolor());
            }
        }
        return temp;
    }

//    public void update()

    public void printboard(){
        for (int i=0;i<tiles.length;i++){
            for (int j=0;j<tiles[i].length;j++){
                System.out.print(tiles[i][j].getcolor());
            }

        }
    }
    public Tile[][] gettiles(){
        return tiles;
    }
    public void makepattern(){
        //path = -
        //wall = |
        //start = x
        //end = o
        final String[] maze=new String[] {
                "|||||||||||||||",
                "|-------------|",
                "|-------------|",
                "|-------------|",
                "|-------------|",
                "|------------o|",
                "|-------------|",
                "|x------------|",
                "|-------------|",
                "|-------------|",
                "|-------------|",
                "|-------------|",
                "|-------------|",
                "|-------------|",
                "|||||||||||||||",
        };

        for (int i=0;i<size;i++){
            String row= maze[i];
            for (int j=0;j<size2;j++){
                if (row.charAt(j)==124){
                    tiles[i][j].changecolor("Black");
                    tiles[i][j].changetype(true);

                }else if (row.charAt(j)==45){
                    tiles[i][j].changecolor("Green");
                    tiles[i][j].changetype(false);


                }else if (row.charAt(j)==120){
                    tiles[i][j].changecolor("Blue");
                    tiles[i][j].changetype(false);


                }else if (row.charAt(j)==111){
                    tiles[i][j].changecolor("Red");
                    tiles[i][j].changetype(false);
                    tiles[i][j].makewinpoint(true);


                }
            }
        }


    }
    //step 4=colors show up by clicking and typing. update function. make borders.
    //
    public void makepiece(int x,int y,String type){
        pieces.add(robot= new Piece(x,y,type,turn));
        if (turn==0){
            turn=1;
        }else if (turn==1){
            turn=0;
        }
    }
    public Piece getpiece(int index){
        return pieces.get(index);
    }
    public ArrayList<Piece> getpieces(){
        return pieces;
    }

    public void move(){
        for (int i=0;i<pieces.size();i++){
            pieces.get(i).move(tiles);
            System.out.println("did you win?"+didyouwin());
//            if (didyouwin().equals("blue")){
//                System.out.println("BLUE WIN");
//            }else if (didyouwin().equals("red")){
//                System.out.println("red win");
//            }
        }

    }
    public boolean didyouwin(){
        for (int i=0;i<tiles.length;i++){
            int row=1;
            for (int j=0;j<tiles[0].length;j++){
                if (tiles[i][j].getcolor().equals(tiles[i][j+1].getcolor()) && !(tiles[i][j].getcolor().equals("Green") && !(tiles[i][j].getcolor().equals("Black")))){
                    row++;
                }else{
                    row=1;
                }
                if (row==5){
                    return true;
                }
            }
        }
        return false;


    }

    public boolean isthereapiecethere(int x,int y){
        for (int i=0;i<pieces.size();i++){
            if (pieces.get(i).getxcord()==x && pieces.get(i).getycord()==y){
                tiles[x][y].changepiecestatus(true);
            }else{
            }
        }
        return false;
    }



   public int getxsize(){
        return size;
   }
    public int getysize(){
        return size2;
    }
//    public Roboto getevilrobot(){
//
//    }



}


