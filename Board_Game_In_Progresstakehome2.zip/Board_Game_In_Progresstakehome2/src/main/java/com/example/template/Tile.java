package com.example.template;

public class Tile {

    private String color;
    private boolean isthereawall=false;
    private boolean isthisend=false;
    private boolean isthereapiece=false;


    public Tile(String color1){
        color=color1;

    }

    public String getcolor(){
        return color;
    }
    public void changepiecestatus(boolean x){
        isthereapiece=x;
    }
    public boolean getisthereapiece(){
        return isthereapiece;
    }

    public void changecolor(String color1){
        color=color1;
    }
    public boolean getisthereawall(){
        return isthereawall;
    }
    public void changetype(boolean str){
        isthereawall=str;
    }
    public void makewinpoint(boolean str){
        isthisend=str;
    }

    public boolean getendstatus(){
        return isthisend;
    }

}
